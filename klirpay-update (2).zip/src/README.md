# KlirPay Global — Master MVP (sandbox)

Plateforme d orchestration de paiements B2B, corridor Canada Haiti, extensible USA Caraibes Latam Afrique Europe.

Principes : stablecoin = rail optionnel, jamais de coin maison. Sandbox etiquete, jamais d argent reel. Ledger double-entree = source de verite. Isolation tenant imposee cote backend emulateur. Confirmation humaine obligatoire pour tout flux financier agentique.

Modules : auth RBAC + 2FA-ready, orgs multi-tenant, onboarding KYB, wallets CAD USD HTG + USDC USDT prets, ledger immuable, clients, beneficiaires masques, factures avec calcul serveur, liens #pay, moteur Bank Card Mobile Stablecoin a providers remplacables, idempotence, remboursements, payouts, FX avec devis expires, router, risque 0-100, webhooks signes avec retry, API v1 avec cles sandbox prod, admin, audit, observabilite, IA sur donnees reelles isolees + agent avec confirmation, analytique.

Tests : onglet Tests 75 -> AC-001 a AC-075 + E2E + recovery + integrite financiere + isolation tenant + idempotence 10x.

Dernier rapport : 75/75 PASS, 100 %, statut READY FOR SANDBOX. Certification Sandbox : 7/7 CERTIFIE (ledger source de verite, zero doublon paiement/webhook, isolation tenant serveur, sandbox separe + prod verrouillee sans prestataire reel, IA avec confirmation humaine, providers remplacables, router transparent). Regle maintenue : production reelle exige prestataires conformes + revue legale.
Regle : 75/75 sinon MVP NOT COMPLETE. Production reelle exige prestataires conformes + revue legale.

Donnees : localStorage klirpay_master_v2. Demo owner@demo.klir / Demo1234!. Bouton Reinitialiser dans Reglages.

Logo : src/logo.png (fourni par le fondateur, detoure du TIF original), affiche sidebar + login + page de paiement.
Design system : tokens #0EA2CD / #003B69 / #F7FAFC / #FFFFFF, 70/20/10, homepage hero, sidebar par groupes, dashboard hero + 4 actions, paiement avec resume et confirmation explicite, bottom nav mobile, statuts avec pastille + texte.
Grand public : checklist 5 etapes, liens de paiement + QR (lib inline), sandbox guide, webhooks, aide/FAQ, notifications, equipe par role, securite (2FA, reset passe, verification email), exports CSV, historique client, tarifs sur la homepage.
Espace client : entreprises voient tout dans Clients + Admin. Bouton Acces genere un code KP-XXXXXX par client ; le client touche Espace client sur l accueil, cree son compte et paie ses factures (portail Mes factures, navigation restreinte, isolation par dossier).
Utilisateurs visibles dans Admin (tous comptes + tous clients). Historique local au navigateur : changer de telephone = Reglages, Sauvegarde, Exporter puis Importer le JSON sur l autre appareil.
Revue externe : toggle Sandbox/Prod reserve owner/admin + bandeaux dedies, cockpit avec salutation et corridor Canada-Haiti, wording stablecoin-ready explicite.

## Final correction pass (2026-10-05) — SANDBOX READY
UI/UX professionnelle, zero changement financier : shell sidebar + topbar + breadcrumbs de page, banniere SANDBOX persistante + bascule prod sous confirmation owner/admin, dashboard cockpit 4 actions + corridor CAD-HTG visuel + upcoming/history payouts + outstanding invoices, wallets par devise avec pending, transactions avec recherche/filtres + ledger immuable, paiement/payout en etapes avec modales de confirmation explicites, factures (creer/envoyer/lien/recu/rembourser/editer DRAFT), page de paiement publique rebrandee, FX avec devis structure, Stablecoin Payments — Sandbox (aucun coin maison), API Sandbox vs Production + rotation, webhooks avec retry, admin (paiements/payouts/fees/risk/audit avec recherche), notifications categorisees, assistant IA avec suggestions, accessibilite (skip link, focus, modales Esc, statuts texte+icone), responsive verifie 1440 et 390. Verifie : 75/75 PASS, 7/7 CERTIFIE, 0 erreur console.