# KlirPay Global — Master MVP (sandbox)

Plateforme d orchestration de paiements B2B, corridor Canada Haiti, extensible USA Caraibes Latam Afrique Europe.

Principes : stablecoin = rail optionnel, jamais de coin maison. Sandbox etiquete, jamais d argent reel. Ledger double-entree = source de verite. Prototype navigateur local : cloisonnement par organisation via garde locale + cles API par org, donnees par appareil (localStorage), aucun controle serveur. Confirmation humaine obligatoire pour tout flux financier agentique.

Modules : auth RBAC + 2FA-ready, orgs multi-tenant, onboarding KYB, wallets CAD USD HTG + USDC USDT prets, ledger immuable, clients, beneficiaires masques, factures avec calcul local verifie, liens #pay locaux a l'appareil, moteur Bank Card Mobile Stablecoin a providers remplacables, idempotence, remboursements, payouts, FX avec devis expires, router, risque 0-100, webhooks signes avec retry, API v1 avec cles sandbox prod, admin, audit, observabilite, IA sur donnees reelles isolees + agent avec confirmation, analytique.

Tests : onglet Tests 75 -> AC-001 a AC-075 + E2E + recovery + integrite financiere + cloisonnement local + idempotence 10x. Les scores affiches sont des auto-controles du prototype local, pas un audit independant ni une preuve serveur.

Dernier rapport : 75/75 PASS en auto-controle local, statut PRET POUR DEMO SANDBOX LOCALE (non independant, backend requis avant pilote). Certification locale : 7/7 (ledger source de verite, zero doublon paiement/webhook, garde anti-cross-org locale, sandbox simule + prod verrouillee sans prestataire reel, IA avec confirmation humaine, providers remplacables, router transparent). Regle maintenue : production reelle exige backend multi-tenant + prestataires conformes + revue legale.
Regle : 75/75 en auto-controle sinon DEMO NON TERMINEE. Pas de pilote multi-utilisateur, pas de KYB reel, pas de flux financiers sans backend.

Donnees : localStorage klirpay_master_v2. Demo owner@demo.klir / Demo1234!. Bouton Reinitialiser dans Reglages.

Logo : src/logo.png (fourni par le fondateur, detoure du TIF original), affiche sidebar + login + page de paiement.
Design system : tokens #0EA2CD / #003B69 / #F7FAFC / #FFFFFF, 70/20/10, homepage hero, sidebar par groupes, dashboard hero + 4 actions, paiement avec resume et confirmation explicite, bottom nav mobile, statuts avec pastille + texte.
Grand public : checklist 5 etapes, liens de paiement + QR (lib inline), sandbox guide, webhooks, aide/FAQ, notifications, equipe par role, securite (2FA, reset passe, verification email), exports CSV, historique client, tarifs sur la homepage.
Espace client : entreprises voient tout dans Clients + Admin. Bouton Acces genere un code KP-XXXXXX par client ; le client touche Espace client sur l accueil, cree son compte et paie ses factures (portail Mes factures, navigation restreinte, isolation par dossier).
Utilisateurs visibles dans Admin (tous comptes + tous clients). Historique local au navigateur : changer de telephone = Reglages, Sauvegarde, Exporter puis Importer le JSON sur l autre appareil.
Revue externe : toggle Sandbox/Prod reserve owner/admin + bandeaux dedies, cockpit avec salutation et corridor Canada-Haiti, wording stablecoin-ready explicite.

## Correctifs audit externe (2026-10-05)
Lien de paiement sur le domaine de deploiement, invoice.sent au lieu de invoice.paid, esc() avec guillemets, secret webhook par organisation, AC-054 strict (BLOCKED refuse), 13 tests tautologiques reecrits en assertions reelles. Portee honnete : prototype navigateur local, donnees par appareil, pas d'isolation serveur — un backend (API, DB, KDF, prestataires) reste requis avant tout pilote multi-utilisateur. Verifie : 75/75 PASS, 7/7 CERTIFIE.

## Liens tracables par page (2026-10-05)
Chaque bouton de navigation ecrit un vrai lien : #app=factures, #app=wallets, etc. (plus #auth=login/signup/client et #pay= publics). Retour navigateur, refresh et partage de lien conservent la page. Page invalide = retour Overview. Verifie : 75/75 PASS, 7/7 CERTIFIE.

## Revue externe n°2 — resserrement (2026-10-05)
AC-003/007/025/026/038/039/040/046/057/060/066/073 durcis (session explicite avec restauration, statuts vérifiés, remboursements avec effet ledger, simulateur stablecoin refuse/émet, jeux non vides exigés, garde anti-cross-org testée par exécution refusée, retry webhook ré-émet lié). AC-005/006/015/030 : garde longueur ajoutée. CERT-03/CERT-04 et aide : libellés honnêtes « prototype local, pas serveur ». Statut suite : LOCAL DEMO READY (auto-contrôle). Limites admises : liens #pay limités à l'appareil, webhooks locaux simulés, secrets et hachages non cryptographiques, XSS : esc() sur les valeurs mais interpolations HTML dynamiques restantes — pas d'encodage contextuel universel.
## Profil + fin de la connexion auto (2026-10-05)
Page Profil dans le menu : logo d'entreprise (upload, redimensionné, affiché sidebar), noms modifiables, raccourci Réglages, notifications, déconnexion. Ouverture du lien = page d'accueil, connexion explicite obligatoire (boutons démo conservés). Verifie : 75/75 PASS, 7/7 CERTIFIE.

## Pages d'auth separees (2026-10-05) — un ecran = une page
Accueil, Connexion (#auth=login), Inscription (#auth=signup, champs reels : nom, email, mot de passe, entreprise, pays), Espace client (#auth=client), puis Overview + 21 pages app apres login. Bouton retour navigateur OK. FIX : [hidden]{display:none!important} (le display:flex ecrasait hidden et empilait auth + overview). Boutons auth en colonne pleine largeur. Verifie : 75/75 PASS, 7/7 CERTIFIE, 0 erreur console.

## Final correction pass (2026-10-05) — SANDBOX READY
UI/UX professionnelle, zero changement financier : shell sidebar + topbar + breadcrumbs de page, banniere SANDBOX persistante + bascule prod sous confirmation owner/admin, dashboard cockpit 4 actions + corridor CAD-HTG visuel + upcoming/history payouts + outstanding invoices, wallets par devise avec pending, transactions avec recherche/filtres + ledger immuable, paiement/payout en etapes avec modales de confirmation explicites, factures (creer/envoyer/lien/recu/rembourser/editer DRAFT), page de paiement publique rebrandee, FX avec devis structure, Stablecoin Payments — Sandbox (aucun coin maison), API Sandbox vs Production + rotation, webhooks avec retry, admin (paiements/payouts/fees/risk/audit avec recherche), notifications categorisees, assistant IA avec suggestions, accessibilite (skip link, focus, modales Esc, statuts texte+icone), responsive verifie 1440 et 390. Verifie : 75/75 PASS, 7/7 CERTIFIE, 0 erreur console.